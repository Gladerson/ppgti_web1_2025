document.addEventListener("DOMContentLoaded", function() {

    const habilidades = {
        gerenciamento: ["Monitoramento", "Segurança", "pfSense", "XCP-ng Server", "Virtualização", "Servidores Linux", "Windows Server"],
        suporte: ["Suporte Técnico", "Hardware", "Software", "Atendimento ao Usuário"],
        outras: ["Zigbee", "Automação", "ESP", "Arduino", "Raspbarry", "LoRA", "Visão Computacional"]
    };

    const container = document.getElementById("habilidades-container");

    document.getElementById("btn-gerenciamento").addEventListener("click", function() {
        exibirHabilidades("gerenciamento");
    });
    
    document.getElementById("btn-suporte").addEventListener("click", function() {
        exibirHabilidades("suporte");
    });

    document.getElementById("btn-outras").addEventListener("click", function() {
        exibirHabilidades("outras");
    });

    document.getElementById("btn-limpar").addEventListener("click", function() {
        container.innerHTML = "";
    });

    function exibirHabilidades(categoria) {
        const skills = habilidades[categoria];
        
        skills.forEach(function(skill) {
            const badge = document.createElement("span");
            badge.className = "badge bg-primary me-2 mb-2 p-2";
            badge.textContent = skill;
            container.appendChild(badge);
        });
    }

    const form = document.getElementById("form-contato");
    const msgDiv = document.getElementById("form-msg");

    form.addEventListener("submit", function(event) {
        event.preventDefault();
        
        msgDiv.innerHTML = '<div class="alert alert-success">Mensagem enviada com sucesso!</div>';
        
        form.reset();

        setTimeout(function() {
            msgDiv.innerHTML = "";
        }, 3000);
    });

});